import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import sharp from 'sharp';

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

export const handler = async event => {
    try {
        const s3Record = event.Records[0].s3;
        const params = parseS3Event(s3Record);
     
        const { 
            sourceBucket, 
            sourceKey,
            destinationBucket, 
            destinationKey, 
            width, 
            height
        } = params;

        console.log(`Resize ${sourceKey} width ${width} and height ${height} from ${sourceBucket} to ${destinationKey} in ${destinationBucket} bucket`);
        
        // Step 1: Retrieve image from public bucket
        const getObjectCommand = new GetObjectCommand({
            Bucket: sourceBucket,
            Key: sourceKey,
        });

        const getObjectResponse = await s3Client.send(getObjectCommand);
        const imageBuffer = await streamToBuffer(getObjectResponse.Body);

        // Step 2: Resize the image
        const sharpInstance = sharp(imageBuffer);
        const metadata = await sharpInstance.metadata();

        const resizeOptions = {
            width,
            height
        };

        let resizedBuffer;
        const format = metadata.format;

        if (format === 'png') {
            resizedBuffer = await sharpInstance
                .resize(resizeOptions)
                .png({ quality: 100 })
                .toBuffer();
        } else if (format === 'webp') {
            resizedBuffer = await sharpInstance
                .resize(resizeOptions)
                .webp({ quality: 100 })
                .toBuffer();
        } else {
            resizedBuffer = await sharpInstance
                .resize(resizeOptions)
                .jpeg({ quality: 100 })
                .toBuffer();
        }

        const resizedMetadata = await sharp(resizedBuffer).metadata();
       
        // Step 3: Upload resized image to destination bucket
        console.log(`Upload resized ${destinationKey} to ${destinationBucket} bucket`);

        const putObjectCommand = new PutObjectCommand({
            Bucket: destinationBucket,
            Key: destinationKey,
            Body: resizedBuffer,
            ContentType: getContentType(format)
        });

        await s3Client.send(putObjectCommand);

        const responseBody = {
            success: true,
            message: 'Image resized and uploaded successfully',
            source: {
                bucket: sourceBucket,
                key: sourceKey,
                size: imageBuffer.length,
                dimensions: `${metadata.width}x${metadata.height}`,
            },
            destination: {
                bucket: destinationBucket,
                key: destinationKey,
                size: resizedBuffer.length,
                dimensions: `${resizedMetadata.width}x${resizedMetadata.height}`,
            },
            compressionRatio: ((1 - resizedBuffer.length / imageBuffer.length) * 100).toFixed(2),
        };

        console.log('Image resized and uploaded successfully:', responseBody);

        // For S3 events and direct invocation
        return {
            statusCode: 200,
            body: JSON.stringify(responseBody),
        };
    } catch (error) {
        console.error('Error processing image:', error);

        const errorResponse = {
            success: false,
            error: error.message,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
        };

        return {
            statusCode: 500,
            body: JSON.stringify(errorResponse),
        };
    }
};

/**
 * Convert a stream to a buffer
 * @param {ReadableStream} stream - Stream to convert
 * @returns {Promise<Buffer>} Buffer containing stream data
 */
async function streamToBuffer(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}

/**
 * Get content type based on image format
 * @param {string} format - Image format
 * @returns {string} Content type string
 */
function getContentType(format) {
    const contentTypes = {
        jpeg: 'image/jpeg',
        jpg: 'image/jpeg',
        png: 'image/png',
        webp: 'image/webp',
        gif: 'image/gif',
        svg: 'image/svg+xml',
    };
    return contentTypes[format?.toLowerCase()] || 'image/jpeg';
}

/**
 * Parse S3 event structure
 * @param {Object} s3Record - S3 event record
 * @returns {Object} Parsed parameters
 */
function parseS3Event(s3Record) {
    const sourceBucket = s3Record.bucket.name;
    const sourceKey = decodeURIComponent(s3Record.object.key.replace(/\+/g, ' '));

    const destinationBucket = process.env.DESTINATION_BUCKET;
    const destinationKey = sourceKey;

    const width = parseInt(process.env.RESIZE_WIDTH, 10);
    const height = parseInt(process.env.RESIZE_HEIGHT, 10);

    return {
        sourceBucket,
        sourceKey,
        destinationBucket,
        destinationKey,
        width,
        height
    };
}
