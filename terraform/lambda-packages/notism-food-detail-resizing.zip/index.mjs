import { S3Client, GetObjectCommand, PutObjectCommand } from '@aws-sdk/client-s3';
import sharp from 'sharp';

const s3Client = new S3Client({ region: process.env.AWS_REGION || 'us-east-1' });

export const handler = async (event) => {
    try {
        const s3Record = event.Records[0].s3;
        const params = parseS3Event(s3Record);

        const {
            sourceBucket,
            sourceKey,
            destinationBucket,
            destinationKey,
            width,
            height
        } = params;

        console.log(`Resize ${sourceKey} width ${width} and height ${height} from ${sourceBucket} to ${destinationKey} in ${destinationBucket} bucket`);

        // Step 1: Retrieve image from private bucket
        const getObjectCommand = new GetObjectCommand({
            Bucket: sourceBucket,
            Key: sourceKey,
        });

        const getObjectResponse = await s3Client.send(getObjectCommand);
        const imageBuffer = await streamToBuffer(getObjectResponse.Body);

        // Step 2: Resize the image
        const sharpInstance = sharp(imageBuffer);
        const metadata = await sharpInstance.metadata();

        const resizeOptions = {
            width,
            height
        };

        let resizedBuffer;
        const format = metadata.format;

        if (format === 'png') {
            resizedBuffer = await sharpInstance
                .resize(resizeOptions)
                .png({ quality: 100 })
                .toBuffer();
        } else if (format === 'webp') {
            resizedBuffer = await sharpInstance
                .resize(resizeOptions)
                .webp({ quality: 100 })
                .toBuffer();
        } else {
            resizedBuffer = await sharpInstance
                .resize(resizeOptions)
                .jpeg({ quality: 100 })
                .toBuffer();
        }

        const resizedMetadata = await sharp(resizedBuffer).metadata();

        // Step 3: Upload resized image to destination bucket
        console.log(`Upload resized ${destinationKey} to ${destinationBucket} bucket`);

        const putObjectCommand = new PutObjectCommand({
            Bucket: destinationBucket,
            Key: destinationKey,
            Body: resizedBuffer,
            ContentType: getContentType(format)
        });

        await s3Client.send(putObjectCommand);

        const responseBody = {
            success: true,
            message: 'Image resized and uploaded successfully',
            source: {
                bucket: sourceBucket,
                key: sourceKey,
                size: imageBuffer.length,
                dimensions: `${metadata.width}x${metadata.height}`,
            },
            destination: {
                bucket: destinationBucket,
                key: destinationKey,
                size: resizedBuffer.length,
                dimensions: `${resizedMetadata.width}x${resizedMetadata.height}`,
            },
            compressionRatio: ((1 - resizedBuffer.length / imageBuffer.length) * 100).toFixed(2),
        };

        console.log('Image resized and uploaded successfully:', responseBody);

        return {
            statusCode: 200,
            body: JSON.stringify(responseBody),
        };
    } catch (error) {
        console.error('Error processing image:', error);

        const errorResponse = {
            success: false,
            error: error.message,
            stack: process.env.NODE_ENV === 'development' ? error.stack : undefined,
        };

        return {
            statusCode: 500,
            body: JSON.stringify(errorResponse),
        };
    }
};

async function streamToBuffer(stream) {
    const chunks = [];
    for await (const chunk of stream) {
        chunks.push(chunk);
    }
    return Buffer.concat(chunks);
}

function getContentType(format) {
    const contentTypes = {
        jpeg: 'image/jpeg',
        jpg: 'image/jpeg',
        png: 'image/png',
        webp: 'image/webp',
        gif: 'image/gif',
        svg: 'image/svg+xml',
    };
    return contentTypes[format?.toLowerCase()] || 'image/jpeg';
}

function parseS3Event(s3Record) {
    const sourceBucket = s3Record.bucket.name;
    const sourceKey = decodeURIComponent(s3Record.object.key.replace(/\+/g, ' '));

    const destinationBucket = process.env.DESTINATION_BUCKET;
    const width = parseInt(process.env.RESIZE_WIDTH, 10);
    const height = parseInt(process.env.RESIZE_HEIGHT, 10);

    // If DESTINATION_PREFIX is set, replace the first path segment (e.g. "food" -> "food-detail")
    let destinationKey;
    const destinationPrefix = process.env.DESTINATION_PREFIX;
    if (destinationPrefix) {
        const firstSlash = sourceKey.indexOf('/');
        destinationKey = firstSlash >= 0
            ? `${destinationPrefix}/${sourceKey.substring(firstSlash + 1)}`
            : sourceKey;
    } else {
        destinationKey = sourceKey;
    }

    return {
        sourceBucket,
        sourceKey,
        destinationBucket,
        destinationKey,
        width,
        height
    };
}
